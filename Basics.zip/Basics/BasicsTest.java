public class BasicsTest {
    public static void main(String[] args) {
        Basics compute = new Basics();
        int[] arr = {2, 18, 10, 14};
        compute.greaterThanY(arr, 5);
        compute.shiftArrVals(arr);
        
    }
}